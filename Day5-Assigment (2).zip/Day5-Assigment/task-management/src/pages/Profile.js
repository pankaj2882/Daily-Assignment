import React from "react";

const Profile = () => {
  return (
    <div className="container profile mt-5">
      <h2>Profile Page</h2>
      <p>User-specific information goes here.</p>
    </div>
  );
};

export default Profile;
